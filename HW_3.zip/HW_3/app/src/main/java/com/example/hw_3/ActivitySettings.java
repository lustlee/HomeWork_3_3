package com.example.hw_3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ActivitySettings extends AppCompatActivity {


    Button btn_settings;
    EditText et_call;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        et_call=findViewById(R.id.et_settings);
        btn_settings = findViewById(R.id.btn_search);
        btn_settings.setOnClickListener(view -> {
            String url = "http://google.com/"+et_call.getText().toString();
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            startActivity(i);
        });


    }
}